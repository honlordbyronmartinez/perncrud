--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE byronmartinez;
ALTER ROLE byronmartinez WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;






\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: byronmartinez; Type: DATABASE; Schema: -; Owner: byronmartinez
--

CREATE DATABASE byronmartinez WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE byronmartinez OWNER TO byronmartinez;

\connect byronmartinez

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: crud-practice-1; Type: DATABASE; Schema: -; Owner: byronmartinez
--

CREATE DATABASE "crud-practice-1" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE "crud-practice-1" OWNER TO byronmartinez;

\connect -reuse-previous=on "dbname='crud-practice-1'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: crm; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.crm (
    id integer NOT NULL,
    first character varying(100),
    last character varying(100),
    email text NOT NULL,
    phone character varying(100),
    location character varying(100),
    hobby character varying(100),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.crm OWNER TO byronmartinez;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.projects (
    id_project integer NOT NULL,
    projectname character varying(100),
    status character varying(100),
    notes character varying(1000),
    clientname character varying(100),
    code character varying(4),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO byronmartinez;

--
-- Name: projects_id_project_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.projects_id_project_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_project_seq OWNER TO byronmartinez;

--
-- Name: projects_id_project_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.projects_id_project_seq OWNED BY public.projects.id_project;


--
-- Name: testtable1_id_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.testtable1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.testtable1_id_seq OWNER TO byronmartinez;

--
-- Name: testtable1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.testtable1_id_seq OWNED BY public.crm.id;


--
-- Name: crm id; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm ALTER COLUMN id SET DEFAULT nextval('public.testtable1_id_seq'::regclass);


--
-- Name: projects id_project; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects ALTER COLUMN id_project SET DEFAULT nextval('public.projects_id_project_seq'::regclass);


--
-- Data for Name: crm; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.crm (id, first, last, email, phone, location, hobby, added) FROM stdin;
1	Byron	Martinez	byron.martinez@stadiummusicenterprise.com	8187300278	North Hollywood	sex	2019-10-03 17:54:36.431
2	Yolanda	Martinez	yolanda.martinez@gmail.com	818.730.7703	Los Angeles	Running	2019-10-03 18:25:14.093
5	Daniel	McBride	d.mcbride@love.com	818.333.6789	Santa Monica, CA	law	2019-10-04 04:00:16.008
3	Amyah	Martinez	amyah.martinez@gmail.com	8187300278	North Hollywood	Roblux	2019-10-03 19:05:05.621
6	Maria	Flores	maria.flores@yahoo.com	501-678-0987	Rivas Estate, Griga	travel	2019-10-04 04:52:23.056
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.projects (id_project, projectname, status, notes, clientname, code, added) FROM stdin;
\.


--
-- Name: projects_id_project_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.projects_id_project_seq', 1, false);


--
-- Name: testtable1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.testtable1_id_seq', 6, true);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id_project);


--
-- Name: crm testtable1_email_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm
    ADD CONSTRAINT testtable1_email_key UNIQUE (email);


--
-- Name: crm testtable1_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm
    ADD CONSTRAINT testtable1_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pipelinevfx; Type: DATABASE; Schema: -; Owner: byronmartinez
--

CREATE DATABASE pipelinevfx WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE pipelinevfx OWNER TO byronmartinez;

\connect pipelinevfx

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bids; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.bids (
    id_bids integer NOT NULL,
    bidname character varying(100),
    status character varying(100),
    notes character varying(1000),
    clientname character varying(100),
    code character varying(4),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.bids OWNER TO byronmartinez;

--
-- Name: bids_id_bids_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.bids_id_bids_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bids_id_bids_seq OWNER TO byronmartinez;

--
-- Name: bids_id_bids_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.bids_id_bids_seq OWNED BY public.bids.id_bids;


--
-- Name: bidsli; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.bidsli (
    id_bidsli integer NOT NULL,
    id_bids integer NOT NULL,
    p1_val integer,
    p2_val integer,
    p3_val integer,
    p4_val integer,
    p5_val integer,
    p6_val integer,
    factor integer,
    qty integer,
    unit character varying(255),
    rate integer,
    total integer,
    is_header boolean NOT NULL,
    itemname character varying(255),
    notes character varying(255),
    creation_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bidsli OWNER TO byronmartinez;

--
-- Name: bidsli_id_bidsli_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.bidsli_id_bidsli_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.bidsli_id_bidsli_seq OWNER TO byronmartinez;

--
-- Name: bidsli_id_bidsli_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.bidsli_id_bidsli_seq OWNED BY public.bidsli.id_bidsli;


--
-- Name: crm; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.crm (
    id_crm integer NOT NULL,
    first character varying(100),
    last character varying(100),
    email text NOT NULL,
    phone character varying(100),
    location character varying(100),
    hobby character varying(100),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.crm OWNER TO byronmartinez;

--
-- Name: crm_id_crm_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.crm_id_crm_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crm_id_crm_seq OWNER TO byronmartinez;

--
-- Name: crm_id_crm_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.crm_id_crm_seq OWNED BY public.crm.id_crm;


--
-- Name: episodes; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.episodes (
    id_episodes integer NOT NULL,
    episodename character varying(100),
    status character varying(100),
    notes character varying(1000),
    clientname character varying(100),
    episodenum character varying(4),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.episodes OWNER TO byronmartinez;

--
-- Name: episodes_id_episodes_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.episodes_id_episodes_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.episodes_id_episodes_seq OWNER TO byronmartinez;

--
-- Name: episodes_id_episodes_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.episodes_id_episodes_seq OWNED BY public.episodes.id_episodes;


--
-- Name: operators; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.operators (
    id_operators integer NOT NULL,
    operatorname character varying(100),
    projectname character varying(100),
    episodename character varying(100),
    servicename character varying(100),
    shotname character varying(100),
    clientname character varying(100),
    status character varying(100),
    notes character varying(1000),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.operators OWNER TO byronmartinez;

--
-- Name: operators_id_operators_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.operators_id_operators_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operators_id_operators_seq OWNER TO byronmartinez;

--
-- Name: operators_id_operators_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.operators_id_operators_seq OWNED BY public.operators.id_operators;


--
-- Name: phase; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.phase (
    id_phase integer NOT NULL,
    id_bidsli integer NOT NULL,
    p1_title character varying(255),
    p2_title character varying(255),
    p3_title character varying(255),
    p4_title character varying(255),
    p5_title character varying(255),
    p6_title character varying(255),
    creation_stamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.phase OWNER TO byronmartinez;

--
-- Name: phase_id_phase_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.phase_id_phase_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.phase_id_phase_seq OWNER TO byronmartinez;

--
-- Name: phase_id_phase_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.phase_id_phase_seq OWNED BY public.phase.id_phase;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.projects (
    id_projects integer NOT NULL,
    projectname character varying(100),
    status character varying(100),
    notes character varying(1000),
    clientname character varying(100),
    code character varying(4),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO byronmartinez;

--
-- Name: projects_id_project_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.projects_id_project_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_project_seq OWNER TO byronmartinez;

--
-- Name: projects_id_project_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.projects_id_project_seq OWNED BY public.projects.id_projects;


--
-- Name: services; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.services (
    id_services integer NOT NULL,
    servicename character varying(100),
    projectname character varying(100),
    episodename character varying(100),
    shotname character varying(100),
    clientname character varying(100),
    status character varying(100),
    notes character varying(1000),
    keywords character varying(100),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.services OWNER TO byronmartinez;

--
-- Name: services_id_services_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.services_id_services_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_services_seq OWNER TO byronmartinez;

--
-- Name: services_id_services_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.services_id_services_seq OWNED BY public.services.id_services;


--
-- Name: shots; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.shots (
    id_shots integer NOT NULL,
    shotname character varying(100),
    projectname character varying(100),
    episodename character varying(100),
    clientname character varying(100),
    status character varying(100),
    notes character varying(1000),
    keywords character varying(100),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.shots OWNER TO byronmartinez;

--
-- Name: shots_id_shots_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.shots_id_shots_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shots_id_shots_seq OWNER TO byronmartinez;

--
-- Name: shots_id_shots_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.shots_id_shots_seq OWNED BY public.shots.id_shots;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.tasks (
    id_tasks integer NOT NULL,
    taskname character varying(100),
    operatorname character varying(100),
    projectname character varying(100),
    episodename character varying(100),
    servicename character varying(100),
    shotname character varying(100),
    clientname character varying(100),
    status character varying(100),
    notes character varying(1000),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.tasks OWNER TO byronmartinez;

--
-- Name: tasks_id_tasks_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.tasks_id_tasks_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_tasks_seq OWNER TO byronmartinez;

--
-- Name: tasks_id_tasks_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.tasks_id_tasks_seq OWNED BY public.tasks.id_tasks;


--
-- Name: bids id_bids; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bids ALTER COLUMN id_bids SET DEFAULT nextval('public.bids_id_bids_seq'::regclass);


--
-- Name: bidsli id_bidsli; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bidsli ALTER COLUMN id_bidsli SET DEFAULT nextval('public.bidsli_id_bidsli_seq'::regclass);


--
-- Name: crm id_crm; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm ALTER COLUMN id_crm SET DEFAULT nextval('public.crm_id_crm_seq'::regclass);


--
-- Name: episodes id_episodes; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.episodes ALTER COLUMN id_episodes SET DEFAULT nextval('public.episodes_id_episodes_seq'::regclass);


--
-- Name: operators id_operators; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.operators ALTER COLUMN id_operators SET DEFAULT nextval('public.operators_id_operators_seq'::regclass);


--
-- Name: phase id_phase; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.phase ALTER COLUMN id_phase SET DEFAULT nextval('public.phase_id_phase_seq'::regclass);


--
-- Name: projects id_projects; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects ALTER COLUMN id_projects SET DEFAULT nextval('public.projects_id_project_seq'::regclass);


--
-- Name: services id_services; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.services ALTER COLUMN id_services SET DEFAULT nextval('public.services_id_services_seq'::regclass);


--
-- Name: shots id_shots; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.shots ALTER COLUMN id_shots SET DEFAULT nextval('public.shots_id_shots_seq'::regclass);


--
-- Name: tasks id_tasks; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id_tasks SET DEFAULT nextval('public.tasks_id_tasks_seq'::regclass);


--
-- Data for Name: bids; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.bids (id_bids, bidname, status, notes, clientname, code, added) FROM stdin;
1	Big Bid Numbers	Awaiting Approval	This is where the shit hits the fan	Netflix	BBNR	2019-10-10 04:12:34
5	Let's delete This one	Awaiting Approval	This bid will self destruct in 10 mins	For REal Delete	UNIQ	2019-10-07 14:12:45.062
\.


--
-- Data for Name: bidsli; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.bidsli (id_bidsli, id_bids, p1_val, p2_val, p3_val, p4_val, p5_val, p6_val, factor, qty, unit, rate, total, is_header, itemname, notes, creation_stamp) FROM stdin;
\.


--
-- Data for Name: crm; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.crm (id_crm, first, last, email, phone, location, hobby, added) FROM stdin;
1	Byron	Martinez	byron.martinez@stadiummusicenterprise.com	8187300278	North Hollywood	law	2019-10-04 05:21:23.071
2	Yolanda	Martinez	yolanda.martinez@gmail.com	818.730.7702	NoHo, CA	Running	2019-10-04 05:22:31.69
4	Amyah	Martinez	nohosnow@gmail.com	818.990.5231	North Hollywood, CA	Roblux	2019-10-04 05:53:03.604
5	Love	Hurts	love.hurts@gmail.com	818.000.9999	LA, CA	react	2019-10-04 10:36:23.663
6	John	Doe	john.doe@gmail.com	555.444.3333	South Park, CO	skiing	2019-10-04 10:37:11.63
7	Sinclair	Johnson	s.johnson@yahoo.com	888.333.2222	Irvine, CA	school	2019-10-04 10:38:01.155
8	Gladis	Gamboa	ggamboa@ill.com	333.444.5555	North Hollywood	wrestling	2019-10-04 10:38:42.795
9	Elaine	Benyss	e.benyss@lycos.com	777.909.4433	NY, NY	driving	2019-10-04 10:39:40.763
10	Jane	Doe	jane.doe@postal.gov	999.000.7777	Scour, PA	Here	2019-10-04 10:40:47.715
11	Adamn	Schiff	adams@house.gov	202.345.4321	Washington DC, DC	politics	2019-10-04 13:23:30.333
12	Ivan	Martinez	ivan.martinez@gmail.com	310.876.2345	Hawthorne, CA	retired	2019-10-04 13:24:22.347
13	Gene	Trash	gene.trash@videostore.com	838.445.0987	Solar, NJ	kicking	2019-10-06 08:35:23.946
14	still	good	still.good@mail.com	345.444.2345	city, state	great	2019-10-06 13:51:10.992
\.


--
-- Data for Name: episodes; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.episodes (id_episodes, episodename, status, notes, clientname, episodenum, added) FROM stdin;
2	Sunflower Tower	Awarded	good notes	HBO	free	2019-10-08 06:27:44.395
4	hmm	Awaiting Approval	which delete	Sir Byron Gamboa	four	2019-10-08 06:34:41.05
\.


--
-- Data for Name: operators; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.operators (id_operators, operatorname, projectname, episodename, servicename, shotname, clientname, status, notes, added) FROM stdin;
1	Chris Composer	This is US	Crabcakes Worry	Composition	030_45_023	Disney	In progress	Why me..	2019-10-05 06:33:36
4	Timmy Tracker	You and Restless	Sunflower Tower	Tracking	030_45_235	Jesus	Awaiting Approval	delete test	2019-10-08 17:20:42.048
\.


--
-- Data for Name: phase; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.phase (id_phase, id_bidsli, p1_title, p2_title, p3_title, p4_title, p5_title, p6_title, creation_stamp) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.projects (id_projects, projectname, status, notes, clientname, code, added) FROM stdin;
1	This is Us	Pending	Make sure we get the assets	Tom Jordan	tius	2019-10-10 11:34:09
16	You and Restless	Approved	I need to figure out how to get rid of place holder text	Sir Byron Gamboa	yiws	2019-10-07 13:52:24.854
18	Meet The Press	Awarded	lots of changes....making sure shit still works	Synthai MacFadden	besf	2019-10-07 15:10:21.407
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.services (id_services, servicename, projectname, episodename, shotname, clientname, status, notes, keywords, added) FROM stdin;
1	Tracking	This is Us	Red Water	030_45_235	HBO	In Progress	notesy	black	2019-10-10 02:34:19
4	Scrubbing	You and Restless	Crazy	030_45_233	Byron Gamboa	Awaiting Approval	hmmmm.	go go	2019-10-08 17:19:18.05
\.


--
-- Data for Name: shots; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.shots (id_shots, shotname, projectname, episodename, clientname, status, notes, keywords, added) FROM stdin;
1	030_45_234	This is US	Sky is theLimit	Byron Gamboa	Needs Finishing	Yeah! its up	fire, smoke, water	2019-10-07 03:11:23
2	030_45_235	This is Them	Sunflower Tower	HBO	Awarded	Add me	water, snow	2019-10-08 05:13:59.641
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.tasks (id_tasks, taskname, operatorname, projectname, episodename, servicename, shotname, clientname, status, notes, added) FROM stdin;
1	Matte Painting	Mathew Matte	Panacea	Matte Painting	Matte Painting	800_59_345	theGrio	Finished	howdy	2019-11-11 11:11:11
2	taskyyy	operator	project	episodey	service	shot	client	status	notes	2019-10-10 10:10:10
4	By by	Timmy Tracker	Meet The Press	Crazy	Matte Painting	786_09_909	HBO	Love	delete	2019-10-08 17:33:34.516
\.


--
-- Name: bids_id_bids_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.bids_id_bids_seq', 5, true);


--
-- Name: bidsli_id_bidsli_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.bidsli_id_bidsli_seq', 1, false);


--
-- Name: crm_id_crm_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.crm_id_crm_seq', 14, true);


--
-- Name: episodes_id_episodes_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.episodes_id_episodes_seq', 4, true);


--
-- Name: operators_id_operators_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.operators_id_operators_seq', 4, true);


--
-- Name: phase_id_phase_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.phase_id_phase_seq', 1, false);


--
-- Name: projects_id_project_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.projects_id_project_seq', 18, true);


--
-- Name: services_id_services_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.services_id_services_seq', 4, true);


--
-- Name: shots_id_shots_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.shots_id_shots_seq', 3, true);


--
-- Name: tasks_id_tasks_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.tasks_id_tasks_seq', 4, true);


--
-- Name: bids bids_code_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_code_key UNIQUE (code);


--
-- Name: bids bids_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bids
    ADD CONSTRAINT bids_pkey PRIMARY KEY (id_bids);


--
-- Name: bidsli bidsli_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bidsli
    ADD CONSTRAINT bidsli_pkey PRIMARY KEY (id_bidsli);


--
-- Name: crm crm_email_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm
    ADD CONSTRAINT crm_email_key UNIQUE (email);


--
-- Name: crm crm_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crm
    ADD CONSTRAINT crm_pkey PRIMARY KEY (id_crm);


--
-- Name: episodes episodes_episodenum_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_episodenum_key UNIQUE (episodenum);


--
-- Name: episodes episodes_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.episodes
    ADD CONSTRAINT episodes_pkey PRIMARY KEY (id_episodes);


--
-- Name: operators operators_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT operators_pkey PRIMARY KEY (id_operators);


--
-- Name: phase phase_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.phase
    ADD CONSTRAINT phase_pkey PRIMARY KEY (id_phase);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id_projects);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id_services);


--
-- Name: shots shots_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.shots
    ADD CONSTRAINT shots_pkey PRIMARY KEY (id_shots);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id_tasks);


--
-- Name: bidsli bidsli_id_bids_fkey; Type: FK CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.bidsli
    ADD CONSTRAINT bidsli_id_bids_fkey FOREIGN KEY (id_bids) REFERENCES public.bids(id_bids) ON DELETE CASCADE;


--
-- Name: phase phase_id_bidsli_fkey; Type: FK CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.phase
    ADD CONSTRAINT phase_id_bidsli_fkey FOREIGN KEY (id_bidsli) REFERENCES public.bidsli(id_bidsli) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sample_db; Type: DATABASE; Schema: -; Owner: byronmartinez
--

CREATE DATABASE sample_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE sample_db OWNER TO byronmartinez;

\connect sample_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: crud_practice_1; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.crud_practice_1 (
    id integer NOT NULL,
    first character varying(100),
    last character varying(100),
    email text NOT NULL,
    phone character varying(100),
    location character varying(100),
    hobby character varying(100),
    added timestamp without time zone NOT NULL
);


ALTER TABLE public.crud_practice_1 OWNER TO byronmartinez;

--
-- Name: crud_practice_1_id_seq; Type: SEQUENCE; Schema: public; Owner: byronmartinez
--

CREATE SEQUENCE public.crud_practice_1_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.crud_practice_1_id_seq OWNER TO byronmartinez;

--
-- Name: crud_practice_1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: byronmartinez
--

ALTER SEQUENCE public.crud_practice_1_id_seq OWNED BY public.crud_practice_1.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: byronmartinez
--

CREATE TABLE public.people (
    id integer,
    first_name character varying(255),
    last_name character varying(255),
    age integer,
    occupation character varying(255)
);


ALTER TABLE public.people OWNER TO byronmartinez;

--
-- Name: crud_practice_1 id; Type: DEFAULT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crud_practice_1 ALTER COLUMN id SET DEFAULT nextval('public.crud_practice_1_id_seq'::regclass);


--
-- Data for Name: crud_practice_1; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.crud_practice_1 (id, first, last, email, phone, location, hobby, added) FROM stdin;
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: byronmartinez
--

COPY public.people (id, first_name, last_name, age, occupation) FROM stdin;
5	Magaret	Martinez	59	Ideal Staff
6	Helen	Martinez	58	Caretaker
7	Francis	Martinez	57	Engineer
8	Marva	Martinez	51	Legal Assistant
9	Ivan Jr	Martinez	31	Driver
10	Ivan Sr	Martinez	60	Retired
11	Shamara	Augustine	32	Realtor
12	Alrick	Augustine	34	Influencer
13	Dwayne	Estero	33	Driver
14	Shawnie	Estero	35	Pharmacist
15	Kimberlie	Miguel	31	Unknown
16	Jason	Locario	41	General Contractor
17	Kobe	Martinez	23	Producer
18	Yannick	Koffi	34	Entertainer
19	Mark	Martinez	31	Unemployed
20	Tyler	Enriquez	13	Student
1	Byron	Martinez	40	Developer
2	Yolanda	Martinez	43	Nurse
3	Emeni	Martinez	12	Student
4	Amyah	Martinez	10	Student
\.


--
-- Name: crud_practice_1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: byronmartinez
--

SELECT pg_catalog.setval('public.crud_practice_1_id_seq', 1, false);


--
-- Name: crud_practice_1 crud_practice_1_email_key; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crud_practice_1
    ADD CONSTRAINT crud_practice_1_email_key UNIQUE (email);


--
-- Name: crud_practice_1 crud_practice_1_pkey; Type: CONSTRAINT; Schema: public; Owner: byronmartinez
--

ALTER TABLE ONLY public.crud_practice_1
    ADD CONSTRAINT crud_practice_1_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sample_db2; Type: DATABASE; Schema: -; Owner: byronmartinez
--

CREATE DATABASE sample_db2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE sample_db2 OWNER TO byronmartinez;

\connect sample_db2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

